﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserWebApi.Models;

namespace UerApi.Service
{
    interface IUser
    {
        List<User> GetAllUser();
        User GetUserByName(String name);
        bool AddUser(User user);
    }
}

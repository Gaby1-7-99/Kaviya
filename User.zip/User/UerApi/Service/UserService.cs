﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserWebApi;
using UserWebApi.Models;

namespace UerApi.Service
{
    public class UserService : IUser
    {
        public UserContext context = null;
        public UserService()
        {
            context = new UserContext();
        }
        public bool AddUser(User user)
        {
            context.Users.Add(user);
            context.SaveChanges();
            return true;
        }

        public List<User> GetAllUser()
        {
            List<User> users = context.Users.ToList();
            return users;
        }

        public User GetUserByName(string name)
        {
            User user = context.Users.SingleOrDefault(s => s.name == name);
            return user;
        }
    }
}


﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UerApi.Service;
using UserWebApi.Models;

namespace UerApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        UserService userService = null;
        public UserController()
        {
            userService = new UserService();
        }
        // GET: api/<UserController>
        [HttpGet]
        [Route("GetAllUser")]
        public IActionResult Get()
        {
            try
            {
                return Ok(userService.GetAllUser()); ;

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        // POST api/<UserController>
        [HttpPost]
        [Consumes("application/json")]
        [Route("Adduser")]
        public IActionResult Post(User user)
        {
            try
            {
                userService.AddUser(user);
                return Ok("User Added");

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
                //Console.Write(ex.InnerException);
            }
        }
        [HttpGet]
        [Consumes("application/json")]
        [Route("GetUserByName/{name}")]
        public IActionResult Get(string name)
        {
            try
            {
                return Ok(userService.GetUserByName(name));

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UserWebApi.Models
{
    public class User
    {
        [Key]
        public string name { get; set; }
        public int age { get; set; }
        public string dob { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string address { get; set; }
        public string phone { get; set; }
    }
}
